C'est une version prototype d'un jeu de parcours.
Elle a été faite pour que je m'entraîne sur les différents moteurs de jeu existant.
Elle possède donc quelques bugs et n'a pas de fin propre.